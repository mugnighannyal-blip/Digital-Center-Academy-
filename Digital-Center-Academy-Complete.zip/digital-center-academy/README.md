# Digital Center Academy (DCA)

**Belajar Dunia Digital, Membangun Masa Depan.**

Platform pembelajaran online berbahasa Indonesia untuk Cyber Security dan Dunia Digital.

## Fitur

- Login Google (Firebase Authentication)
- Dashboard dengan progress belajar, badge, level
- Materi lengkap (Dasar Komputer, Hardware, Software, OS, Networking, Malware, Cyber Security, dll)
- Quiz interaktif per materi (10 soal, penilaian otomatis, pembahasan)
- Progress tersimpan di Firestore
- Sertifikat (siap dikembangkan lebih lanjut)
- Desain Dark Theme Premium + Glassmorphism
- Fully Responsive
- Framer Motion animations

## Teknologi

- Next.js 15 (App Router)
- React 19 + TypeScript
- Tailwind CSS 4
- Firebase (Auth, Firestore, Storage)
- Framer Motion
- Lucide Icons

## Cara Menjalankan

```bash
# Install dependencies
npm install

# Jalankan development server
npm run dev

# Build untuk production
npm run build
npm start
```

Buka [http://localhost:3000](http://localhost:3000)

## Deploy ke Vercel

1. Push repository ini ke GitHub
2. Import project di [vercel.com](https://vercel.com)
3. Deploy (otomatis, tidak perlu konfigurasi tambahan)

## Firebase

Konfigurasi Firebase sudah terintegrasi. Pastikan:

- Google Sign-In diaktifkan di Firebase Console
- Firestore dalam mode production atau test sesuai kebutuhan
- Storage rules diatur sesuai keperluan

## Struktur Folder

```
src/
├── app/           # Pages (App Router)
├── components/    # UI Components
├── contexts/      # React Contexts (Auth)
├── data/          # Materials & Quizzes data
├── hooks/         # Custom hooks
├── lib/           # Firebase & utilities
├── types/         # TypeScript types
└── utils/         # Helper functions
```

## Lisensi

Proyek edukasi. Silakan digunakan untuk pembelajaran.
