import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAnUHOmaXWyK_7C4ey72MgcBJnHqvtQ7OE",
  authDomain: "web-belajar-cyber-security.firebaseapp.com",
  projectId: "web-belajar-cyber-security",
  storageBucket: "web-belajar-cyber-security.firebasestorage.app",
  messagingSenderId: "740323749324",
  appId: "1:740323749324:web:e26a802cbb5a083a658169",
  measurementId: "G-X5QWJ4T7GP"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

export default app;
