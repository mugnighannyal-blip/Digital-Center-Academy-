import { Material } from "@/types";

export const materials: Material[] = [
  {
    id: "dasar-komputer",
    title: "Dasar Komputer",
    slug: "dasar-komputer",
    category: "Dasar",
    description: "Memahami konsep fundamental komputer, komponen utama, dan bagaimana komputer bekerja.",
    content: {
      pengertian: "Komputer adalah perangkat elektronik yang dapat menerima data (input), memproses data tersebut sesuai perintah (program), menyimpan data, dan menghasilkan informasi (output). Komputer modern terdiri dari hardware (perangkat keras) dan software (perangkat lunak) yang saling bekerja sama.",
      sejarah: "Sejarah komputer dimulai dari abacus hingga ENIAC (1946), kemudian generasi transistor, IC, mikroprosesor, hingga komputer pribadi dan smartphone saat ini.",
      caraKerja: "Komputer bekerja berdasarkan arsitektur Von Neumann: Fetch, Decode, Execute, Store. Data masuk melalui input, diproses CPU dengan bantuan RAM, disimpan di storage, dan ditampilkan melalui output.",
      dampak: "Komputer mengubah pendidikan, bisnis, komunikasi, hiburan, kesehatan, dan penelitian. Ketergantungan juga membawa tantangan kesenjangan digital dan privasi.",
      contohKasus: "Belajar online, WFH, otomatisasi pabrik, CAD, diagnosis medis, dan manajemen rumah sakit.",
      pencegahan: "Pahami dasar-dasarnya agar dapat menggunakan komputer secara efektif dan aman.",
      perlindungan: "Antivirus, update rutin, password kuat, backup data, hindari software tidak terpercaya.",
      ringkasan: "Komputer adalah fondasi dunia digital. Pengetahuan dasar menjadi pintu gerbang topik lanjutan seperti jaringan, pemrograman, dan keamanan siber."
    },
    duration: "45 menit",
    level: "Pemula",
    icon: "Monitor",
    order: 1,
    tags: ["dasar", "komputer"]
  },
  {
    id: "virus-komputer",
    title: "Virus Komputer",
    slug: "virus-komputer",
    category: "Malware",
    description: "Memahami virus komputer, cara kerja, dampak, dan cara melindungi diri.",
    content: {
      pengertian: "Virus komputer adalah malware yang mereplikasi diri dengan menyisipkan kode berbahaya ke dalam program atau file sah. Virus membutuhkan 'inang' dan eksekusi oleh pengguna untuk menyebar.",
      sejarah: "Creeper (1971) adalah virus pertama. Brain (1986) virus PC pertama. Era 1990-2000 melihat ILOVEYOU, Melissa, CIH. Saat ini digantikan malware modern yang lebih canggih.",
      caraKerja: "Tahap: Infeksi (sisipkan kode), Replikasi (salin ke file lain), Aktivasi (jalankan payload), Penyebaran (email, USB, unduhan). Bisa resident atau non-resident.",
      dampak: "Dari mengganggu hingga merusak data, menurunkan performa, mencuri informasi, dan biaya pemulihan tinggi.",
      contohKasus: "ILOVEYOU (2000) menyebar via email dan menginfeksi jutaan komputer, kerugian miliaran dolar. CIH dapat merusak BIOS.",
      pencegahan: "Jangan buka attachment tidak dikenal. Hindari unduhan tidak resmi. Nonaktifkan AutoRun. Antivirus update. Hati-hati macro Office.",
      perlindungan: "Antivirus real-time, firewall, backup offline, update OS dan aplikasi, aplikasi whitelist di perusahaan.",
      ringkasan: "Virus adalah ancaman klasik. Kesadaran pengguna dan kebiasaan aman lebih efektif daripada mengandalkan antivirus semata."
    },
    duration: "60 menit",
    level: "Pemula",
    icon: "Bug",
    order: 50,
    tags: ["malware", "virus"]
  },
  {
    id: "malware",
    title: "Malware",
    slug: "malware",
    category: "Malware",
    description: "Pengertian menyeluruh tentang malware dan jenis-jenis ancamannya.",
    content: {
      pengertian: "Malware adalah istilah payung untuk software berbahaya yang merusak, mengganggu, mencuri data, atau mendapatkan akses tidak sah. Termasuk virus, worm, trojan, ransomware, spyware, adware, rootkit, dan lainnya.",
      sejarah: "Dari virus floppy 1980-an, Morris Worm 1988, hingga ransomware WannaCry 2017 dan serangan supply-chain SolarWinds.",
      caraKerja: "Masuk via phishing, drive-by download, crack, USB, atau exploit. Kemudian mereplikasi, menyembunyikan diri, mencuri data, mengenkripsi file, atau bergabung ke botnet. Fileless malware hanya hidup di memori.",
      dampak: "Kerugian finansial, pencurian identitas, gangguan operasional, kerusakan reputasi, dan ancaman infrastruktur kritis.",
      contohKasus: "WannaCry menginfeksi ratusan ribu komputer di 150 negara. NotPetya menyebabkan kerugian miliar dolar sebagai wiper.",
      pencegahan: "Defense in depth: update, antivirus/EDR, firewall, email filtering, training, least privilege, segmentasi, backup terisolasi.",
      perlindungan: "EDR modern, MFA, monitor jaringan, security awareness, incident response plan, backup 3-2-1.",
      ringkasan: "Malware terus berevolusi. Memahami jenis dan vektor serangan memungkinkan strategi pertahanan efektif."
    },
    duration: "70 menit",
    level: "Pemula",
    icon: "ShieldAlert",
    order: 51,
    tags: ["malware", "ancaman"]
  },
  {
    id: "trojan",
    title: "Trojan",
    slug: "trojan",
    category: "Malware",
    description: "Memahami Trojan Horse dan mengapa sangat berbahaya.",
    content: {
      pengertian: "Trojan menyamar sebagai software sah untuk menipu pengguna agar menginstalnya. Tidak mereplikasi diri, tetapi dapat membuka backdoor, mencuri data, atau mengunduh malware lain.",
      sejarah: "Nama dari Kuda Troya. Trojan banking seperti Zeus, Emotet, TrickBot merugikan jutaan orang sejak 2000-an.",
      caraKerja: "Distribusi via phishing, crack, situs palsu. Setelah dijalankan: keylogger, remote access, curi cookie, unduh ransomware, atau jadikan zombie botnet.",
      dampak: "Pintu masuk serangan lebih besar. Kehilangan kredensial bank, akun, data perusahaan, atau menjadi bagian DDoS.",
      contohKasus: "Zeus mencuri kredensial perbankan. Emotet berkembang menjadi distributor ransomware. Trojan menyamar sebagai update Flash.",
      pencegahan: "Unduh hanya dari sumber resmi. Hindari crack. Periksa digital signature. Browser dengan proteksi phishing.",
      perlindungan: "Antivirus behavior detection, Controlled Folder Access, sandbox, monitor koneksi keluar, password manager + MFA.",
      ringkasan: "Trojan memanfaatkan kepercayaan. Skeptisisme terhadap unduhan dan email adalah pertahanan terbaik."
    },
    duration: "55 menit",
    level: "Pemula",
    icon: "Skull",
    order: 52,
    tags: ["malware", "trojan"]
  },
  {
    id: "worm",
    title: "Worm",
    slug: "worm",
    category: "Malware",
    description: "Mengenal computer worm dan cara penyebarannya otomatis.",
    content: {
      pengertian: "Worm mereplikasi dan menyebar otomatis melalui jaringan tanpa file host atau intervensi pengguna. Memanfaatkan kerentanan sistem atau protokol.",
      sejarah: "Morris Worm (1988) adalah yang pertama terkenal. Code Red, Blaster, Sasser, WannaCry, dan Stuxnet adalah contoh penting.",
      caraKerja: "Mencari komputer rentan, menyalin diri, mengulangi. Bisa via email, shared folder, atau removable media. Sering membawa payload tambahan.",
      dampak: "Menyumbat bandwidth, crash sistem, menyebar sangat cepat ke ribuan komputer. Biaya pembersihan tinggi.",
      contohKasus: "WannaCry menggunakan EternalBlue. Conficker menciptakan botnet besar. Stuxnet menargetkan SCADA fasilitas nuklir Iran.",
      pencegahan: "Patch segera. Nonaktifkan service tidak perlu. Segmentasi jaringan. Firewall ketat. Monitor traffic.",
      perlindungan: "Least privilege, IDS/IPS, backup, prosedur isolasi cepat, edukasi USB dan attachment.",
      ringkasan: "Worm berbahaya karena penyebaran otomatis. Patch management dan segmentasi adalah kunci."
    },
    duration: "50 menit",
    level: "Menengah",
    icon: "Network",
    order: 53,
    tags: ["malware", "worm"]
  },
  {
    id: "ransomware",
    title: "Ransomware",
    slug: "ransomware",
    category: "Malware",
    description: "Ancaman ransomware, enkripsi, dan strategi pertahanan.",
    content: {
      pengertian: "Ransomware mengenkripsi file korban dan meminta tebusan cryptocurrency. Varian modern juga mencuri data (double extortion).",
      sejarah: "AIDS Trojan akhir 1980-an. CryptoLocker 2013 memulai era modern. WannaCry, Ryuk, Conti, LockBit, dan RaaS mendominasi.",
      caraKerja: "Masuk via phishing/RDP/exploit. Enkripsi file penting, hapus shadow copy, tampilkan catatan tebusan. Sering ekstrak data dulu.",
      dampak: "Menghentikan operasional, biaya tebusan + pemulihan + downtime bisa jutaan dolar. Beberapa organisasi tutup.",
      contohKasus: "WannaCry memengaruhi NHS. Colonial Pipeline 2021. Serangan rumah sakit dan pemerintah daerah semakin sering.",
      pencegahan: "Backup offline teruji. Patch. Amankan RDP dengan MFA+VPN. Email filtering. Training. Segmentasi. Least privilege.",
      perlindungan: "EDR, monitor IOC, incident response plan, jangan bayar tanpa konsultasi, cyber insurance.",
      ringkasan: "Backup teruji adalah pertahanan terakhir paling efektif. Pencegahan melalui patching dan kesadaran sangat krusial."
    },
    duration: "65 menit",
    level: "Menengah",
    icon: "Lock",
    order: 54,
    tags: ["malware", "ransomware"]
  },
  {
    id: "spyware",
    title: "Spyware",
    slug: "spyware",
    category: "Malware",
    description: "Spyware dan perlindungan privasi.",
    content: {
      pengertian: "Spyware mengumpulkan informasi pengguna tanpa sepengetahuan: aktivitas browsing, keystroke, kredensial, lokasi, bahkan kamera/mikrofon.",
      sejarah: "Populer era 2000-an dengan adware. Berkembang menjadi tools pengawasan dan stalkerware. Pegasus adalah contoh canggih.",
      caraKerja: "Instal via bundling, exploit, phishing, atau physical access. Berjalan background, kirim data ke penyerang. Bisa pakai teknik rootkit.",
      dampak: "Pencurian identitas, penipuan, pelanggaran privasi, spionase industri, atau penguntitan.",
      contohKasus: "Pegasus zero-click di iOS/Android. Utility tools 'gratis' yang memasang spyware.",
      pencegahan: "Sumber instalasi jelas. Periksa permission. Ad-blocker. Waspadai izin tidak masuk akal. Application control.",
      perlindungan: "Antispyware/EDR, audit aplikasi, VPN, enkripsi data, perhatikan battery/data usage, factory reset jika perlu.",
      ringkasan: "Spyware mengancam privasi. Kesadaran permission dan sumber instalasi adalah kunci."
    },
    duration: "45 menit",
    level: "Pemula",
    icon: "Eye",
    order: 55,
    tags: ["malware", "spyware"]
  },
  {
    id: "phishing",
    title: "Phishing",
    slug: "phishing",
    category: "Social Engineering",
    description: "Serangan phishing dan cara menghindarinya.",
    content: {
      pengertian: "Phishing adalah social engineering di mana penyerang menyamar sebagai entitas terpercaya untuk mencuri informasi sensitif via email, SMS (smishing), telepon (vishing), atau media sosial.",
      sejarah: "Muncul 1990-an. Spearfishing dan Business Email Compromise (BEC) semakin canggih seiring e-commerce dan remote work.",
      caraKerja: "Pesan mendesak dengan link ke situs palsu atau attachment berbahaya. Setelah kredensial dimasukkan, langsung disalahgunakan.",
      dampak: "Kehilangan uang, identitas, kompromi akun perusahaan, dan sering menjadi awal ransomware.",
      contohKasus: "BEC meniru CEO untuk transfer dana. Phishing COVID-19. Situs wallet crypto palsu. Breach Target dimulai dari phishing vendor.",
      pencegahan: "Periksa pengirim teliti. Ketik URL langsung. MFA. Verifikasi permintaan sensitif via saluran lain. Email gateway proteksi.",
      perlindungan: "Laporkan phishing. Password unik + manager. Monitor rekening. Simulasi phishing di organisasi.",
      ringkasan: "Phishing mengeksploitasi manusia. Kewaspadaan, verifikasi ganda, dan MFA adalah pertahanan terbaik."
    },
    duration: "50 menit",
    level: "Pemula",
    icon: "MailWarning",
    order: 60,
    tags: ["phishing", "social-engineering"]
  },
  {
    id: "kriptografi",
    title: "Kriptografi",
    slug: "kriptografi",
    category: "Keamanan",
    description: "Dasar kriptografi, enkripsi, hashing, dan penerapannya.",
    content: {
      pengertian: "Kriptografi melindungi informasi dengan mengubahnya menjadi bentuk tidak terbaca tanpa kunci. Tujuan: kerahasiaan, integritas, autentikasi, non-repudiation.",
      sejarah: "Dari Caesar cipher hingga Enigma, DES, RSA, AES, TLS. Saat ini post-quantum cryptography dikembangkan.",
      caraKerja: "Simetris (AES) cepat tapi distribusi kunci sulit. Asimetris (RSA/ECC) aman distribusi tapi lambat. Hashing (SHA-256) satu arah. Digital signature gabungan keduanya.",
      dampak: "Fondasi transaksi online, chat terenkripsi, VPN, password storage, dan SSL.",
      contohKasus: "HTTPS/TLS, Signal/WhatsApp E2EE, password hashing, Bitcoin cryptography.",
      pencegahan: "Gunakan algoritma aman (hindari MD5/SHA-1/DES). Jangan buat sendiri. Library teruji. Kelola kunci benar.",
      perlindungan: "HTTPS, bcrypt/Argon2 + salt, private key aman, update library, perfect forward secrecy.",
      ringkasan: "Kriptografi tulang punggung keamanan digital. Pahami konsep dasar untuk menghindari kesalahan fatal."
    },
    duration: "70 menit",
    level: "Menengah",
    icon: "Key",
    order: 70,
    tags: ["kriptografi", "enkripsi"]
  },
  {
    id: "cyber-security",
    title: "Cyber Security",
    slug: "cyber-security",
    category: "Keamanan",
    description: "Pengantar keamanan siber, CIA triad, dan karir di bidang ini.",
    content: {
      pengertian: "Cyber Security melindungi sistem, jaringan, dan data dari serangan digital. Fokus pada Confidentiality, Integrity, Availability (CIA Triad). Mencakup teknis, proses, dan manusia.",
      sejarah: "Dari era mainframe hingga breach modern dan regulasi GDPR serta UU PDP Indonesia.",
      caraKerja: "Defense in depth di level jaringan, endpoint, aplikasi, data, dan manusia. Tools: firewall, IDS/IPS, SIEM, EDR, encryption, IAM. Framework: NIST, ISO 27001, CIS.",
      dampak: "Kegagalan menyebabkan kerugian besar. Keamanan baik membangun kepercayaan dan memungkinkan inovasi.",
      contohKasus: "Equifax 2017, Colonial Pipeline, SolarWinds. Banyak instansi di Indonesia juga menjadi target.",
      pencegahan: "Least privilege, patch, MFA, backup, segmentasi, training. Keamanan adalah proses berkelanjutan.",
      perlindungan: "Program prevent-detect-respond-recover. Risk assessment. Incident response plan. Asuransi siber. Investasi pada orang.",
      ringkasan: "Cyber security luas dan sangat dibutuhkan. Pahami prinsip dasar untuk melindungi aset digital."
    },
    duration: "70 menit",
    level: "Pemula",
    icon: "Shield",
    order: 40,
    tags: ["cybersecurity", "keamanan"]
  },
  {
    id: "linux",
    title: "Linux",
    slug: "linux",
    category: "Sistem Operasi",
    description: "Pengenalan Linux, command line, dan keunggulannya di server.",
    content: {
      pengertian: "Linux adalah OS open-source berbasis Unix. Kernel oleh Linus Torvalds 1991. Dominan di server, supercomputer, embedded, dan Android.",
      sejarah: "Kernel 1991 + GNU tools. Distro: Debian, Ubuntu, Fedora, Arch, Kali. Tulang punggung internet.",
      caraKerja: "Kernel kelola hardware. Shell sebagai antarmuka. Package manager. Everything is a file. Permission rwx.",
      dampak: "Server murah, stabil, aman. Sebagian besar website dan cloud berjalan di Linux.",
      contohKasus: "Ubuntu Server VPS, Rocky Linux enterprise, Kali untuk security, Android, Raspberry Pi.",
      pencegahan: "Jangan root default. Sudo bijak. Update rutin. Minimal package. Firewall.",
      perlindungan: "Disable root SSH, key auth, fail2ban, monitor log, SELinux/AppArmor, backup konfigurasi.",
      ringkasan: "Linux wajib untuk server, cloud, DevOps, keamanan siber. Command line membuka banyak kemungkinan."
    },
    duration: "80 menit",
    level: "Pemula",
    icon: "Terminal",
    order: 10,
    tags: ["linux", "server"]
  },
  {
    id: "python",
    title: "Python",
    slug: "python",
    category: "Pemrograman",
    description: "Pengenalan Python dan penerapannya di otomasi serta keamanan.",
    content: {
      pengertian: "Python bahasa tingkat tinggi dengan sintaks bersih. Interpreted, multi-paradigm, ekosistem library kaya. Digunakan di data science, AI, web, otomasi, keamanan siber.",
      sejarah: "Guido van Rossum, rilis 1991. Python 3 saat ini standar. Termasuk bahasa paling populer.",
      caraKerja: "Interpreter jalankan kode. Indentasi wajib. Dynamic typing. Virtual environment. pip + PyPI.",
      dampak: "Menurunkan barrier pemrograman. Banyak tools keamanan ditulis Python. Dominan di ML dan data.",
      contohKasus: "Otomasi backup, scraping, analisis log, tool pentest (legal), Django/Flask, TensorFlow.",
      pencegahan: "Hati-hati script tidak dikenal. Virtual environment. Periksa kerentanan dependencies.",
      perlindungan: "Jangan hardcode credential. Environment variable. Validasi input. Update library. Secure coding.",
      ringkasan: "Python powerful dan ramah pemula. Sangat direkomendasikan untuk otomasi dan keamanan siber."
    },
    duration: "75 menit",
    level: "Pemula",
    icon: "Code2",
    order: 20,
    tags: ["python", "pemrograman"]
  },
  {
    id: "networking",
    title: "Networking",
    slug: "networking",
    category: "Jaringan",
    description: "Dasar jaringan komputer, OSI, TCP/IP, dan perangkat jaringan.",
    content: {
      pengertian: "Networking menghubungkan perangkat agar berkomunikasi. LAN, MAN, WAN. Fondasi keamanan siber, cloud, administrasi sistem.",
      sejarah: "ARPANET akhir 1960-an. TCP/IP 1980-an. WWW 1989. Saat ini 5G dan fiber.",
      caraKerja: "Data jadi paket, alamat IP, melewati switch/router. OSI 7 layer, TCP/IP 4 layer. HTTP, DNS, DHCP, ARP.",
      dampak: "Tanpa jaringan tidak ada internet dan cloud. Desain baik memengaruhi performa dan keamanan.",
      contohKasus: "Router rumah, VLAN perusahaan, data center spine-leaf, internet sebagai jaringan dari jaringan.",
      pencegahan: "Amankan router (password, firmware). WPA3. Segmentasi. Monitor perangkat.",
      perlindungan: "Firewall, VPN di publik, nonaktifkan WPS, update firmware.",
      ringkasan: "Networking tulang punggung komunikasi digital. Pahami dasar untuk troubleshooting dan desain aman."
    },
    duration: "60 menit",
    level: "Pemula",
    icon: "Network",
    order: 30,
    tags: ["jaringan", "tcp/ip"]
  },
  {
    id: "password-security",
    title: "Password Security",
    slug: "password-security",
    category: "Keamanan",
    description: "Praktik terbaik mengelola password di era modern.",
    content: {
      pengertian: "Praktik membuat password kuat, menyimpan aman, dan mengelola banyak akun. Password masih umum meski memiliki kelemahan.",
      sejarah: "Dari mainframe hingga rekomendasi passphrase dan MFA karena brute-force semakin mudah.",
      caraKerja: "Penyerang pakai dictionary, brute-force, credential stuffing, phishing, keylogger. Server harus hash dengan bcrypt/Argon2 + salt.",
      dampak: "Password lemah/reused penyebab utama kompromi akun dan account takeover chain.",
      contohKasus: "Banyak breach karena password default/lemah atau stuffing. MD5 tanpa salt mudah di-crack.",
      pencegahan: "Password manager. Unik setiap akun. Passphrase panjang. MFA. Jangan bagikan.",
      perlindungan: "Ganti jika breach (haveibeenpwned). Jangan simpan di browser tanpa master kuat. Kebijakan + MFA di organisasi.",
      ringkasan: "Password unik kuat + MFA adalah dasar. Password manager membuatnya praktis."
    },
    duration: "40 menit",
    level: "Pemula",
    icon: "KeyRound",
    order: 72,
    tags: ["password", "mfa"]
  },
  {
    id: "ethical-hacking",
    title: "Ethical Hacking",
    slug: "ethical-hacking",
    category: "Keamanan",
    description: "Pengenalan ethical hacking dan penetration testing.",
    content: {
      pengertian: "Praktik menguji keamanan dengan izin pemilik untuk menemukan kerentanan sebelum pihak jahat. Menggunakan teknik penyerang dengan tujuan memperbaiki dan mematuhi hukum.",
      sejarah: "Dari komunitas hacker netral hingga sertifikasi CEH, OSCP, dan bug bounty modern.",
      caraKerja: "Fase: Reconnaissance, Scanning, Gaining Access, Maintaining Access, Reporting. Metodologi PTES, OWASP, NIST.",
      dampak: "Membantu temukan dan perbaiki celah, tingkatkan postur keamanan, kepatuhan regulasi.",
      contohKasus: "Bug bounty perusahaan besar membayar jutaan dolar. Pentest wajib di industri keuangan dan kesehatan.",
      pencegahan: "Selalu dengan izin tertulis (Rules of Engagement). Tanpa izin = ilegal.",
      perlindungan: "Organisasi: pentest berkala, perbaiki temuan, awareness. Individu: pelajari legalitas, sertifikasi, lab legal (TryHackMe, HTB).",
      ringkasan: "Ethical hacking penting untuk pertahanan. Lakukan dengan izin dan profesionalisme."
    },
    duration: "60 menit",
    level: "Menengah",
    icon: "UserCheck",
    order: 71,
    tags: ["ethical-hacking", "pentest"]
  },
  {
    id: "html",
    title: "HTML",
    slug: "html",
    category: "Web Development",
    description: "Dasar HTML5 dan struktur dokumen web.",
    content: {
      pengertian: "HTML adalah bahasa markup standar untuk struktur halaman web. Mendefinisikan elemen heading, paragraf, link, gambar, form, dll.",
      sejarah: "Tim Berners-Lee 1991. HTML5 (2014) membawa semantic, audio/video, canvas, API modern.",
      caraKerja: "Browser baca HTML, bangun DOM, render. Tag berpasangan. Atribut tambahan. Semantic membantu aksesibilitas dan SEO.",
      dampak: "Setiap website dibangun di atas HTML. Fondasi web developer.",
      contohKasus: "Landing page, blog, form, struktur dasar aplikasi web modern.",
      pencegahan: "Validasi input. Hindari inline JS/CSS berlebih. Semantic tags. Escape user content (cegah XSS).",
      perlindungan: "CSP, HTTPS, sanitasi output, praktik aksesibilitas WCAG.",
      ringkasan: "HTML fondasi web. Semantic HTML5 wajib untuk pengembang dan pemahaman keamanan klien."
    },
    duration: "45 menit",
    level: "Pemula",
    icon: "FileCode",
    order: 15,
    tags: ["html", "web"]
  }
];

export const categories = [
  { id: "dasar", name: "Dasar Komputer", icon: "Monitor" },
  { id: "sistem-operasi", name: "Sistem Operasi", icon: "HardDrive" },
  { id: "pemrograman", name: "Pemrograman", icon: "Code" },
  { id: "web-development", name: "Web Development", icon: "Globe" },
  { id: "jaringan", name: "Jaringan", icon: "Network" },
  { id: "keamanan", name: "Keamanan Siber", icon: "Shield" },
  { id: "malware", name: "Malware", icon: "Bug" },
  { id: "social-engineering", name: "Social Engineering", icon: "Users" },
];

export function getMaterialBySlug(slug: string): Material | undefined {
  return materials.find((m) => m.slug === slug);
}

export function getMaterialsByCategory(category: string): Material[] {
  return materials.filter((m) => m.category.toLowerCase().includes(category.toLowerCase()));
}
