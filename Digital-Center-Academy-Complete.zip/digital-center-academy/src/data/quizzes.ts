import { Quiz } from "@/types";

export const quizzes: Record<string, Quiz> = {
  "dasar-komputer": {
    materialId: "dasar-komputer",
    passingScore: 70,
    questions: [
      {
        id: "q1",
        question: "Apa kepanjangan dari CPU?",
        options: ["Central Processing Unit", "Computer Personal Unit", "Central Program Utility", "Control Processing Unit"],
        correctAnswer: 0,
        explanation: "CPU adalah Central Processing Unit, otak dari komputer yang memproses instruksi."
      },
      {
        id: "q2",
        question: "Komponen yang menyimpan data sementara saat komputer menyala disebut?",
        options: ["Hard Disk", "RAM", "SSD", "ROM"],
        correctAnswer: 1,
        explanation: "RAM (Random Access Memory) menyimpan data sementara yang sedang digunakan oleh sistem."
      },
      {
        id: "q3",
        question: "Arsitektur komputer modern yang paling umum digunakan adalah?",
        options: ["Harvard Architecture", "Von Neumann Architecture", "Dataflow Architecture", "Quantum Architecture"],
        correctAnswer: 1,
        explanation: "Sebagian besar komputer modern menggunakan arsitektur Von Neumann."
      },
      {
        id: "q4",
        question: "Manakah yang termasuk perangkat input?",
        options: ["Monitor", "Printer", "Keyboard", "Speaker"],
        correctAnswer: 2,
        explanation: "Keyboard adalah perangkat input untuk memasukkan data ke komputer."
      },
      {
        id: "q5",
        question: "Apa fungsi utama dari sistem operasi?",
        options: ["Membuat dokumen", "Mengelola sumber daya hardware dan software", "Menghubungkan ke internet", "Mengedit foto"],
        correctAnswer: 1,
        explanation: "Sistem operasi mengelola seluruh sumber daya hardware dan menyediakan platform bagi aplikasi."
      },
      {
        id: "q6",
        question: "ENIAC adalah contoh komputer generasi?",
        options: ["Pertama", "Kedua", "Ketiga", "Keempat"],
        correctAnswer: 0,
        explanation: "ENIAC (1946) menggunakan vacuum tube dan termasuk komputer generasi pertama."
      },
      {
        id: "q7",
        question: "Proses Fetch-Decode-Execute-Store terjadi di?",
        options: ["RAM", "CPU", "Hard Disk", "GPU"],
        correctAnswer: 1,
        explanation: "Siklus instruksi Fetch-Decode-Execute-Store dilakukan oleh CPU."
      },
      {
        id: "q8",
        question: "Manakah yang merupakan perangkat output?",
        options: ["Mouse", "Scanner", "Monitor", "Microphone"],
        correctAnswer: 2,
        explanation: "Monitor menampilkan hasil pemrosesan, sehingga termasuk perangkat output."
      },
      {
        id: "q9",
        question: "Software yang langsung berinteraksi dengan hardware disebut?",
        options: ["Application Software", "System Software", "Utility Software", "Malware"],
        correctAnswer: 1,
        explanation: "System software (seperti OS dan driver) berinteraksi langsung dengan hardware."
      },
      {
        id: "q10",
        question: "Mengapa penting memahami dasar komputer?",
        options: ["Hanya untuk teknisi", "Agar dapat menggunakan teknologi dengan bijak dan aman", "Tidak penting", "Hanya untuk programmer"],
        correctAnswer: 1,
        explanation: "Memahami dasar membantu menggunakan teknologi secara efektif, efisien, dan aman."
      }
    ]
  },
  "virus-komputer": {
    materialId: "virus-komputer",
    passingScore: 70,
    questions: [
      {
        id: "q1",
        question: "Virus komputer membutuhkan apa untuk menyebar?",
        options: ["Koneksi internet saja", "File host atau program inang", "Hanya USB", "Tidak membutuhkan apa-apa"],
        correctAnswer: 1,
        explanation: "Virus membutuhkan file host (inang) dan biasanya eksekusi oleh pengguna untuk menyebar."
      },
      {
        id: "q2",
        question: "Virus komputer pertama yang dikenal adalah?",
        options: ["ILOVEYOU", "Creeper", "Melissa", "CIH"],
        correctAnswer: 1,
        explanation: "Creeper (1971) dianggap sebagai virus komputer pertama."
      },
      {
        id: "q3",
        question: "Manakah yang BUKAN cara umum penyebaran virus?",
        options: ["Email attachment", "USB terinfeksi", "Update resmi sistem operasi", "Unduhan software tidak resmi"],
        correctAnswer: 2,
        explanation: "Update resmi dari vendor biasanya aman dan justru menutup celah keamanan."
      },
      {
        id: "q4",
        question: "Apa yang dimaksud dengan payload pada virus?",
        options: ["Ukuran file virus", "Bagian kode yang menjalankan aksi berbahaya", "Nama virus", "Cara virus menyebar"],
        correctAnswer: 1,
        explanation: "Payload adalah bagian virus yang menjalankan aksi berbahaya setelah aktivasi."
      },
      {
        id: "q5",
        question: "Virus ILOVEYOU menyebar terutama melalui?",
        options: ["USB", "Email", "Bluetooth", "Wi-Fi"],
        correctAnswer: 1,
        explanation: "ILOVEYOU menyebar massal melalui email dengan subject menarik."
      },
      {
        id: "q6",
        question: "Salah satu cara terbaik mencegah virus adalah?",
        options: ["Menonaktifkan antivirus", "Tidak pernah update sistem", "Tidak membuka attachment mencurigakan", "Menggunakan password yang sama di semua akun"],
        correctAnswer: 2,
        explanation: "Kesadaran tidak membuka file/attachment mencurigakan adalah pertahanan penting."
      },
      {
        id: "q7",
        question: "Virus yang tinggal di memori komputer disebut?",
        options: ["Non-resident virus", "Resident virus", "Macro virus", "Boot virus"],
        correctAnswer: 1,
        explanation: "Resident virus tetap berada di memori bahkan setelah program host selesai."
      },
      {
        id: "q8",
        question: "Mengapa backup data penting terkait virus?",
        options: ["Agar virus tidak bisa masuk", "Untuk memulihkan data jika terinfeksi dan rusak", "Supaya komputer lebih cepat", "Tidak ada hubungannya"],
        correctAnswer: 1,
        explanation: "Backup memungkinkan pemulihan data jika virus berhasil merusak atau menghapus file."
      },
      {
        id: "q9",
        question: "Apa yang harus dilakukan jika mencurigai komputer terinfeksi virus?",
        options: ["Langsung format tanpa backup", "Disconnect dari jaringan dan scan dengan antivirus", "Abaikan saja", "Bagikan password ke orang lain"],
        correctAnswer: 1,
        explanation: "Putus koneksi jaringan untuk cegah penyebaran, lalu scan dan bersihkan."
      },
      {
        id: "q10",
        question: "Virus berbeda dari worm karena?",
        options: ["Virus lebih berbahaya", "Virus membutuhkan host, worm dapat berdiri sendiri", "Worm tidak bisa menyebar", "Tidak ada perbedaan"],
        correctAnswer: 1,
        explanation: "Virus membutuhkan file host, sedangkan worm dapat mereplikasi dan menyebar secara mandiri."
      }
    ]
  },
  "malware": {
    materialId: "malware",
    passingScore: 70,
    questions: [
      {
        id: "q1",
        question: "Malware adalah singkatan dari?",
        options: ["Malicious Hardware", "Malicious Software", "Multiple Software", "Managed Software"],
        correctAnswer: 1,
        explanation: "Malware = Malicious Software, software yang dirancang dengan niat jahat."
      },
      {
        id: "q2",
        question: "Manakah yang termasuk jenis malware?",
        options: ["Firewall", "Ransomware", "Browser", "Spreadsheet"],
        correctAnswer: 1,
        explanation: "Ransomware adalah salah satu jenis malware yang mengenkripsi data korban."
      },
      {
        id: "q3",
        question: "Fileless malware berbeda karena?",
        options: ["Lebih mudah dideteksi", "Hanya hidup di memori tanpa menulis file ke disk", "Tidak berbahaya", "Hanya menyerang mobile"],
        correctAnswer: 1,
        explanation: "Fileless malware beroperasi di memori sehingga lebih sulit dideteksi oleh antivirus tradisional."
      },
      {
        id: "q4",
        question: "WannaCry adalah contoh dari?",
        options: ["Hanya virus", "Worm-ransomware", "Adware biasa", "Spyware"],
        correctAnswer: 1,
        explanation: "WannaCry menggabungkan kemampuan worm untuk menyebar dan ransomware untuk mengenkripsi."
      },
      {
        id: "q5",
        question: "Pertahanan berlapis dalam keamanan disebut?",
        options: ["Single point of failure", "Defense in depth", "Zero protection", "Open access"],
        correctAnswer: 1,
        explanation: "Defense in depth berarti menerapkan banyak lapisan pertahanan."
      },
      {
        id: "q6",
        question: "Apa yang dimaksud dengan RaaS?",
        options: ["Random Access System", "Ransomware as a Service", "Remote Admin Software", "Read as a Service"],
        correctAnswer: 1,
        explanation: "Ransomware as a Service memungkinkan penjahat menyewa infrastruktur ransomware."
      },
      {
        id: "q7",
        question: "Vektor masuk malware yang paling umum adalah?",
        options: ["Update resmi Windows", "Phishing email", "Antivirus", "Firewall"],
        correctAnswer: 1,
        explanation: "Phishing email masih menjadi salah satu vektor masuk malware paling umum."
      },
      {
        id: "q8",
        question: "Mengapa backup 3-2-1 direkomendasikan?",
        options: ["Agar lebih ribet", "3 salinan, 2 media berbeda, 1 offline/air-gapped", "Hanya 1 backup cukup", "Tidak perlu backup"],
        correctAnswer: 1,
        explanation: "Strategi 3-2-1 meningkatkan peluang data bertahan dari serangan ransomware maupun bencana."
      },
      {
        id: "q9",
        question: "EDR adalah singkatan dari?",
        options: ["Email Data Recovery", "Endpoint Detection and Response", "External Drive Reader", "Easy Data Restore"],
        correctAnswer: 1,
        explanation: "Endpoint Detection and Response adalah solusi keamanan modern di level endpoint."
      },
      {
        id: "q10",
        question: "Langkah pertama jika mencurigai infeksi malware?",
        options: ["Bayar tebusan", "Isolasi sistem dari jaringan", "Install ulang semua aplikasi", "Bagikan ke teman"],
        correctAnswer: 1,
        explanation: "Isolasi segera mencegah penyebaran lebih lanjut ke sistem atau jaringan lain."
      }
    ]
  },
  "ransomware": {
    materialId: "ransomware",
    passingScore: 70,
    questions: [
      {
        id: "q1",
        question: "Tujuan utama ransomware adalah?",
        options: ["Mempercepat komputer", "Mengenkripsi data dan meminta tebusan", "Membersihkan virus", "Update sistem"],
        correctAnswer: 1,
        explanation: "Ransomware mengenkripsi file korban dan meminta pembayaran agar data dikembalikan."
      },
      {
        id: "q2",
        question: "Double extortion pada ransomware berarti?",
        options: ["Meminta tebusan dua kali lipat", "Mencuri data + mengenkripsi, lalu ancam publikasi", "Menyerang dua komputer", "Menggunakan dua jenis enkripsi"],
        correctAnswer: 1,
        explanation: "Selain enkripsi, penyerang juga mencuri data dan mengancam akan mempublikasikannya."
      },
      {
        id: "q3",
        question: "Cryptocurrency sering digunakan dalam ransomware karena?",
        options: ["Lebih cepat", "Sulit dilacak", "Lebih murah", "Wajib oleh hukum"],
        correctAnswer: 1,
        explanation: "Cryptocurrency relatif lebih anonim dan sulit dilacak dibanding transfer bank tradisional."
      },
      {
        id: "q4",
        question: "Pertahanan paling efektif terhadap ransomware adalah?",
        options: ["Antivirus saja", "Backup offline yang teruji", "Password lemah", "Menonaktifkan firewall"],
        correctAnswer: 1,
        explanation: "Backup yang baik dan teruji memungkinkan restore tanpa membayar tebusan."
      },
      {
        id: "q5",
        question: "WannaCry memanfaatkan kerentanan apa?",
        options: ["Browser Chrome", "SMB (EternalBlue)", "PDF Reader", "Wi-Fi"],
        correctAnswer: 1,
        explanation: "WannaCry menyebar menggunakan exploit EternalBlue pada protokol SMB Windows."
      },
      {
        id: "q6",
        question: "Apa yang biasanya dilakukan ransomware terhadap shadow copy?",
        options: ["Memperbanyak", "Menghapus atau menonaktifkan", "Mengenkripsi juga", "Tidak ada hubungan"],
        correctAnswer: 1,
        explanation: "Ransomware sering menghapus shadow copy agar korban sulit restore dari Volume Shadow Copy."
      },
      {
        id: "q7",
        question: "Apakah disarankan langsung membayar tebusan ransomware?",
        options: ["Ya, selalu", "Tidak, konsultasikan dulu dengan ahli dan penegak hukum", "Ya jika data penting", "Bayar saja setengah"],
        correctAnswer: 1,
        explanation: "Membayar tidak menjamin data kembali dan mendorong serangan lebih lanjut. Konsultasi dulu."
      },
      {
        id: "q8",
        question: "RDP yang tidak diamankan berisiko terhadap ransomware karena?",
        options: ["Terlalu cepat", "Sering menjadi target brute-force attack", "Tidak bisa dienkripsi", "Hanya untuk Linux"],
        correctAnswer: 1,
        explanation: "RDP yang terbuka ke internet sering di-brute-force sebagai pintu masuk ransomware."
      },
      {
        id: "q9",
        question: "Network segmentation membantu karena?",
        options: ["Membuat jaringan lebih lambat", "Membatasi penyebaran ransomware antar segmen", "Menghilangkan kebutuhan backup", "Tidak ada manfaat"],
        correctAnswer: 1,
        explanation: "Segmentasi membatasi lateral movement sehingga ransomware sulit menyebar ke seluruh jaringan."
      },
      {
        id: "q10",
        question: "Indikator kompromi (IOC) berguna untuk?",
        options: ["Mempercepat enkripsi", "Mendeteksi aktivitas ransomware lebih awal", "Menghapus backup", "Menonaktifkan antivirus"],
        correctAnswer: 1,
        explanation: "IOC membantu deteksi dini aktivitas mencurigakan sebelum enkripsi massal terjadi."
      }
    ]
  },
  "phishing": {
    materialId: "phishing",
    passingScore: 70,
    questions: [
      {
        id: "q1",
        question: "Phishing adalah bentuk dari?",
        options: ["Hardware failure", "Social engineering", "Software update", "Network protocol"],
        correctAnswer: 1,
        explanation: "Phishing adalah teknik social engineering yang menipu manusia, bukan mengeksploitasi bug teknis semata."
      },
      {
        id: "q2",
        question: "Smishing adalah phishing melalui?",
        options: ["Email", "SMS", "Telepon suara", "Surat pos"],
        correctAnswer: 1,
        explanation: "Smishing = SMS phishing."
      },
      {
        id: "q3",
        question: "Ciri umum email phishing adalah?",
        options: ["Pengirim resmi dan tanpa urgensi", "Rasa urgensi dan permintaan data sensitif", "Tanpa link sama sekali", "Hanya berisi gambar"],
        correctAnswer: 1,
        explanation: "Phishing sering menciptakan rasa takut atau urgensi agar korban bertindak cepat tanpa berpikir."
      },
      {
        id: "q4",
        question: "Spear phishing berbeda karena?",
        options: ["Menyerang banyak orang secara acak", "Menargetkan individu atau organisasi spesifik", "Hanya via telepon", "Tidak berbahaya"],
        correctAnswer: 1,
        explanation: "Spear phishing adalah serangan yang sangat bertarget dan dipersonalisasi."
      },
      {
        id: "q5",
        question: "Cara terbaik memverifikasi permintaan transfer dana mendesak?",
        options: ["Langsung transfer", "Verifikasi melalui saluran komunikasi lain yang sudah dikenal", "Balas email yang sama", "Abaikan"],
        correctAnswer: 1,
        explanation: "Selalu verifikasi melalui saluran terpisah (telepon ke nomor resmi, chat internal, dll)."
      },
      {
        id: "q6",
        question: "MFA membantu melawan phishing karena?",
        options: ["Membuat password lebih pendek", "Bahkan jika password dicuri, masih ada faktor tambahan", "Menonaktifkan email", "Menghapus semua link"],
        correctAnswer: 1,
        explanation: "Multi-factor authentication menambahkan lapisan sehingga password saja tidak cukup."
      },
      {
        id: "q7",
        question: "Business Email Compromise (BEC) biasanya menargetkan?",
        options: ["Anak-anak", "Proses keuangan dan transfer dana perusahaan", "Game online", "Media sosial saja"],
        correctAnswer: 1,
        explanation: "BEC sering menyamar sebagai eksekutif atau vendor untuk meminta transfer dana."
      },
      {
        id: "q8",
        question: "Jika ragu terhadap link di email, sebaiknya?",
        options: ["Klik untuk cek", "Hover untuk lihat URL asli atau ketik manual di browser", "Forward ke semua teman", "Download attachment-nya"],
        correctAnswer: 1,
        explanation: "Jangan klik. Periksa URL dengan hover atau akses situs resmi dengan mengetik langsung."
      },
      {
        id: "q9",
        question: "Vishing adalah phishing melalui?",
        options: ["Video", "Suara/telepon", "Virtual reality", "VPN"],
        correctAnswer: 1,
        explanation: "Vishing = voice phishing, dilakukan melalui telepon."
      },
      {
        id: "q10",
        question: "Mengapa simulasi phishing berguna di organisasi?",
        options: ["Untuk menghukum karyawan", "Melatih kesadaran dan mengukur kesiapan terhadap serangan nyata", "Agar email lebih lambat", "Tidak ada manfaat"],
        correctAnswer: 1,
        explanation: "Simulasi membantu karyawan mengenali phishing dan memperkuat budaya keamanan."
      }
    ]
  },
  "cyber-security": {
    materialId: "cyber-security",
    passingScore: 70,
    questions: [
      {
        id: "q1",
        question: "CIA Triad dalam keamanan siber terdiri dari?",
        options: ["Central, Internet, Access", "Confidentiality, Integrity, Availability", "Code, Install, Apply", "Computer, Information, Application"],
        correctAnswer: 1,
        explanation: "CIA = Confidentiality (kerahasiaan), Integrity (integritas), Availability (ketersediaan)."
      },
      {
        id: "q2",
        question: "Confidentiality berarti?",
        options: ["Data selalu tersedia", "Hanya pihak berwenang yang dapat mengakses informasi", "Data tidak boleh diubah", "Sistem tidak pernah down"],
        correctAnswer: 1,
        explanation: "Confidentiality memastikan informasi hanya diakses oleh pihak yang berhak."
      },
      {
        id: "q3",
        question: "Integrity berarti?",
        options: ["Data rahasia", "Data tidak diubah secara tidak sah", "Sistem cepat", "Banyak backup"],
        correctAnswer: 1,
        explanation: "Integrity menjaga agar data tidak dimodifikasi oleh pihak tidak berwenang."
      },
      {
        id: "q4",
        question: "Availability berarti?",
        options: ["Data dienkripsi", "Sistem dan data dapat diakses saat dibutuhkan", "Hanya admin yang bisa login", "Password kuat"],
        correctAnswer: 1,
        explanation: "Availability memastikan layanan dan data tersedia bagi pengguna yang sah saat diperlukan."
      },
      {
        id: "q5",
        question: "Defense in depth berarti?",
        options: ["Satu lapisan keamanan saja", "Banyak lapisan pertahanan", "Tidak perlu keamanan", "Hanya firewall"],
        correctAnswer: 1,
        explanation: "Defense in depth menerapkan multiple layers of security controls."
      },
      {
        id: "q6",
        question: "Least privilege berarti?",
        options: ["Semua orang dapat akses admin", "Pengguna hanya mendapat akses seminimal yang diperlukan", "Tidak ada password", "Akses terbuka"],
        correctAnswer: 1,
        explanation: "Prinsip least privilege membatasi hak akses hanya pada yang benar-benar dibutuhkan."
      },
      {
        id: "q7",
        question: "Framework keamanan siber yang populer dari NIST disebut?",
        options: ["NIST Cybersecurity Framework", "NIST Cooking Framework", "NIST Design Framework", "NIST Marketing Framework"],
        correctAnswer: 0,
        explanation: "NIST Cybersecurity Framework banyak digunakan secara global."
      },
      {
        id: "q8",
        question: "Mengapa manusia sering disebut sebagai mata rantai terlemah?",
        options: ["Karena tidak bisa coding", "Karena dapat ditipu melalui social engineering", "Karena tidak punya komputer", "Karena terlalu pintar"],
        correctAnswer: 1,
        explanation: "Banyak serangan berhasil dengan menipu manusia, bukan memecahkan enkripsi."
      },
      {
        id: "q9",
        question: "Incident response plan berguna untuk?",
        options: ["Mencegah semua serangan", "Menangani insiden keamanan secara terstruktur saat terjadi", "Menghapus semua log", "Menonaktifkan keamanan"],
        correctAnswer: 1,
        explanation: "Rencana respons membantu organisasi bereaksi cepat dan efektif saat insiden terjadi."
      },
      {
        id: "q10",
        question: "Keamanan siber adalah?",
        options: ["Produk sekali beli", "Proses berkelanjutan yang melibatkan teknologi, proses, dan manusia", "Hanya urusan IT", "Tidak penting untuk individu"],
        correctAnswer: 1,
        explanation: "Keamanan siber adalah proses terus-menerus, bukan solusi sekali pasang."
      }
    ]
  }
};

// Generate basic quizzes for other materials
const otherMaterialIds = [
  "trojan", "worm", "spyware", "kriptografi", "linux", "python", 
  "networking", "password-security", "ethical-hacking", "html"
];

otherMaterialIds.forEach((id) => {
  if (!quizzes[id]) {
    quizzes[id] = {
      materialId: id,
      passingScore: 70,
      questions: Array.from({ length: 10 }, (_, i) => ({
        id: `q${i + 1}`,
        question: `Pertanyaan ${i + 1} tentang materi ${id.replace(/-/g, " ")}?`,
        options: [
          "Opsi A - Jawaban benar contoh",
          "Opsi B",
          "Opsi C",
          "Opsi D"
        ],
        correctAnswer: 0,
        explanation: `Penjelasan untuk pertanyaan ${i + 1} pada materi ${id}. Pelajari kembali materi untuk pemahaman lebih dalam.`
      }))
    };
  }
});

export function getQuizByMaterialId(materialId: string): Quiz | undefined {
  return quizzes[materialId];
}
