export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  createdAt: string;
  level: number;
  xp: number;
  badges: string[];
  completedMaterials: string[];
  quizScores: Record<string, number>;
  averageScore: number;
  totalStudyTime: number;
  lastActivity: string;
  certificates: string[];
  isAdmin?: boolean;
}

export interface Material {
  id: string;
  title: string;
  slug: string;
  category: string;
  description: string;
  content: {
    pengertian: string;
    sejarah: string;
    caraKerja: string;
    dampak: string;
    contohKasus: string;
    pencegahan: string;
    perlindungan: string;
    ringkasan: string;
  };
  duration: string;
  level: "Pemula" | "Menengah" | "Lanjutan";
  icon: string;
  order: number;
  tags: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Quiz {
  materialId: string;
  questions: QuizQuestion[];
  passingScore: number;
}

export interface Activity {
  id: string;
  type: "material_complete" | "quiz_complete" | "badge_earned" | "level_up";
  title: string;
  description: string;
  timestamp: string;
  materialId?: string;
  score?: number;
}

export interface Certificate {
  id: string;
  userId: string;
  userName: string;
  issueDate: string;
  materialsCompleted: number;
  averageScore: number;
}
