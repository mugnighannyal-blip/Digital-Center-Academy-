"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  BookOpen,
  FolderOpen,
  HelpCircle,
  TrendingUp,
  Award,
  User,
  Settings,
  Info,
  LogOut,
  Shield,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/utils/cn";
import { useState } from "react";

const menuItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/materi", label: "Semua Materi", icon: BookOpen },
  { href: "/kategori", label: "Kategori", icon: FolderOpen },
  { href: "/quiz", label: "Quiz", icon: HelpCircle },
  { href: "/progress", label: "Progress", icon: TrendingUp },
  { href: "/sertifikat", label: "Sertifikat", icon: Award },
  { href: "/profil", label: "Profil", icon: User },
  { href: "/pengaturan", label: "Pengaturan", icon: Settings },
  { href: "/tentang", label: "Tentang Website", icon: Info },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { profile, signOut } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <motion.aside
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      className={cn(
        "fixed left-0 top-0 h-screen glass-strong z-40 flex flex-col transition-all duration-300",
        collapsed ? "w-20" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="p-4 flex items-center gap-3 border-b border-slate-700/50">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-blue-500 flex items-center justify-center flex-shrink-0">
          <Shield className="w-5 h-5 text-white" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="font-bold text-white text-sm truncate">Digital Center</h1>
            <p className="text-xs text-slate-400">Academy</p>
          </div>
        )}
      </div>

      {/* User info */}
      {!collapsed && profile && (
        <div className="p-4 border-b border-slate-700/50">
          <div className="flex items-center gap-3">
            <img
              src={profile.photoURL || "/default-avatar.png"}
              alt={profile.displayName}
              className="w-10 h-10 rounded-full border-2 border-emerald-500/50"
            />
            <div className="overflow-hidden">
              <p className="text-sm font-medium text-white truncate">{profile.displayName}</p>
              <p className="text-xs text-slate-400">Level {profile.level}</p>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200",
                isActive
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  : "text-slate-400 hover:text-white hover:bg-slate-800/50"
              )}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {!collapsed && <span className="text-sm font-medium">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Collapse & Logout */}
      <div className="p-3 border-t border-slate-700/50 space-y-1">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/50 transition-all"
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
          {!collapsed && <span className="text-sm">Ciutkan</span>}
        </button>
        <button
          onClick={signOut}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-red-400 hover:bg-red-500/10 transition-all"
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span className="text-sm">Keluar</span>}
        </button>
      </div>
    </motion.aside>
  );
}
