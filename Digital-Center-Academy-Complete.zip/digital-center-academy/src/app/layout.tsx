import type { Metadata } from "next";
import { Toaster } from "react-hot-toast";
import { AuthProvider } from "@/contexts/AuthContext";
import "./globals.css";

export const metadata: Metadata = {
  title: "Digital Center Academy | Belajar Dunia Digital & Cyber Security",
  description: "Digital Center Academy adalah platform pembelajaran online berbahasa Indonesia yang menyediakan materi lengkap mengenai dunia digital, komputer, jaringan, server, cloud computing, VPS, hosting, pengembangan aplikasi, pemrograman, serta keamanan siber.",
  keywords: ["cyber security", "keamanan siber", "belajar komputer", "pemrograman", "jaringan", "digital academy", "indonesia"],
  authors: [{ name: "Digital Center Academy" }],
  openGraph: {
    title: "Digital Center Academy",
    description: "Belajar Dunia Digital, Membangun Masa Depan. Platform pembelajaran cyber security dan dunia digital berbahasa Indonesia.",
    type: "website",
    locale: "id_ID",
    siteName: "Digital Center Academy",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body className="antialiased bg-gradient-radial min-h-screen">
        <AuthProvider>
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              style: {
                background: "#1e293b",
                color: "#e2e8f0",
                border: "1px solid rgba(148, 163, 184, 0.2)",
              },
            }}
          />
        </AuthProvider>
      </body>
    </html>
  );
}
