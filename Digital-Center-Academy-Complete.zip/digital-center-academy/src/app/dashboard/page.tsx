"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import Sidebar from "@/components/Sidebar";
import { motion } from "framer-motion";
import {
  BookOpen,
  CheckCircle,
  Award,
  TrendingUp,
  Clock,
  Target,
  Star,
  Zap,
  BarChart3,
  Activity,
} from "lucide-react";
import { materials } from "@/data/materials";
import Link from "next/link";

export default function DashboardPage() {
  const { user, profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push("/");
    }
  }, [user, loading, router]);

  if (loading || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  const completedCount = profile.completedMaterials?.length || 0;
  const totalMaterials = materials.length;
  const progressPercent = Math.round((completedCount / totalMaterials) * 100) || 0;
  const avgScore = profile.averageScore || 0;

  const stats = [
    { label: "Materi Selesai", value: completedCount, icon: CheckCircle, color: "text-emerald-400", bg: "bg-emerald-500/10" },
    { label: "Total Materi", value: totalMaterials, icon: BookOpen, color: "text-blue-400", bg: "bg-blue-500/10" },
    { label: "Nilai Rata-rata", value: `${avgScore}%`, icon: Target, color: "text-cyan-400", bg: "bg-cyan-500/10" },
    { label: "Level", value: profile.level || 1, icon: Zap, color: "text-amber-400", bg: "bg-amber-500/10" },
  ];

  const recentMaterials = materials.slice(0, 5);

  return (
    <div className="min-h-screen bg-gradient-radial">
      <Sidebar />
      <main className="ml-64 p-6 lg:p-8">
        {/* Welcome */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">
            Selamat datang, <span className="gradient-text">{profile.displayName}</span>
          </h1>
          <p className="text-slate-400">
            Lanjutkan perjalanan belajar Anda di dunia digital dan keamanan siber.
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="glass rounded-2xl p-5 card-hover"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center`}>
                  <stat.icon className={`w-5 h-5 ${stat.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold text-white">{stat.value}</p>
              <p className="text-sm text-slate-400">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Progress Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-2 glass rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
                Progress Belajar
              </h2>
              <span className="text-emerald-400 font-bold">{progressPercent}%</span>
            </div>
            
            <div className="w-full bg-slate-800 rounded-full h-3 mb-4">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 1, delay: 0.5 }}
                className="h-3 rounded-full bg-gradient-to-r from-emerald-500 to-blue-500"
              />
            </div>
            
            <p className="text-sm text-slate-400 mb-6">
              {completedCount} dari {totalMaterials} materi telah diselesaikan
            </p>

            {/* Badges */}
            <div>
              <h3 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                Badge yang Dimiliki
              </h3>
              <div className="flex flex-wrap gap-2">
                {(profile.badges || ["Pemula Digital"]).map((badge, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20"
                  >
                    {badge}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Profile Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="glass rounded-2xl p-6"
          >
            <div className="text-center">
              <img
                src={profile.photoURL || "https://via.placeholder.com/100"}
                alt={profile.displayName}
                className="w-20 h-20 rounded-full mx-auto border-4 border-emerald-500/30 mb-4"
              />
              <h3 className="text-lg font-semibold text-white">{profile.displayName}</h3>
              <p className="text-sm text-slate-400 mb-4">{profile.email}</p>
              
              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="glass rounded-xl p-3">
                  <p className="text-lg font-bold text-emerald-400">{profile.xp || 0}</p>
                  <p className="text-xs text-slate-400">XP</p>
                </div>
                <div className="glass rounded-xl p-3">
                  <p className="text-lg font-bold text-blue-400">{profile.certificates?.length || 0}</p>
                  <p className="text-xs text-slate-400">Sertifikat</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Recent Materials & Quick Menu */}
        <div className="grid lg:grid-cols-2 gap-6 mt-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="glass rounded-2xl p-6"
          >
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-400" />
              Materi Terbaru
            </h2>
            <div className="space-y-3">
              {recentMaterials.map((m) => (
                <Link
                  key={m.id}
                  href={`/materi/${m.slug}`}
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-800/50 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center group-hover:bg-emerald-500/20">
                    <BookOpen className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{m.title}</p>
                    <p className="text-xs text-slate-400">{m.category} · {m.duration}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    m.level === "Pemula" ? "bg-emerald-500/10 text-emerald-400" :
                    m.level === "Menengah" ? "bg-amber-500/10 text-amber-400" :
                    "bg-red-500/10 text-red-400"
                  }`}>
                    {m.level}
                  </span>
                </Link>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="glass rounded-2xl p-6"
          >
            <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Menu Cepat
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {[
                { href: "/materi", label: "Semua Materi", icon: BookOpen, color: "emerald" },
                { href: "/quiz", label: "Kerjakan Quiz", icon: Target, color: "blue" },
                { href: "/progress", label: "Lihat Progress", icon: BarChart3, color: "cyan" },
                { href: "/sertifikat", label: "Sertifikat", icon: Award, color: "amber" },
              ].map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="glass rounded-xl p-4 text-center card-hover group"
                >
                  <item.icon className={`w-6 h-6 mx-auto mb-2 text-${item.color}-400 group-hover:scale-110 transition-transform`} />
                  <p className="text-sm font-medium text-white">{item.label}</p>
                </Link>
              ))}
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
