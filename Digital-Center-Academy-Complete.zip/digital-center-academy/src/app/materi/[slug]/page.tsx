"use client";

import { useEffect, use } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import Sidebar from "@/components/Sidebar";
import { motion } from "framer-motion";
import { BookOpen, Clock, BarChart, ArrowLeft, CheckCircle, HelpCircle } from "lucide-react";
import { getMaterialBySlug } from "@/data/materials";
import Link from "next/link";

export default function MaterialDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const { user, profile, loading } = useAuth();
  const router = useRouter();
  const material = getMaterialBySlug(slug);

  useEffect(() => {
    if (!loading && !user) router.push("/");
  }, [user, loading, router]);

  if (loading || !material) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  const isCompleted = profile?.completedMaterials?.includes(material.id);

  const sections = [
    { key: "pengertian", title: "Pengertian" },
    { key: "sejarah", title: "Sejarah Singkat" },
    { key: "caraKerja", title: "Cara Kerja Secara Umum" },
    { key: "dampak", title: "Dampak" },
    { key: "contohKasus", title: "Contoh Kasus" },
    { key: "pencegahan", title: "Cara Pencegahan" },
    { key: "perlindungan", title: "Cara Melindungi Perangkat" },
    { key: "ringkasan", title: "Ringkasan" },
  ] as const;

  return (
    <div className="min-h-screen bg-gradient-radial">
      <Sidebar />
      <main className="ml-64 p-6 lg:p-8 max-w-4xl">
        <Link href="/materi" className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Kembali ke Daftar Materi
        </Link>

        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-start gap-4 mb-6">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-7 h-7 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className={`text-xs px-2 py-1 rounded-full ${
                  material.level === "Pemula" ? "bg-emerald-500/10 text-emerald-400" :
                  material.level === "Menengah" ? "bg-amber-500/10 text-amber-400" :
                  "bg-red-500/10 text-red-400"
                }`}>{material.level}</span>
                <span className="text-xs text-slate-500">{material.category}</span>
                {isCompleted && (
                  <span className="text-xs px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Selesai
                  </span>
                )}
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">{material.title}</h1>
              <p className="text-slate-400">{material.description}</p>
              <div className="flex items-center gap-4 mt-3 text-sm text-slate-500">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {material.duration}</span>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.article
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-2xl p-6 lg:p-8 prose-dark mb-8"
        >
          {sections.map((section) => (
            <div key={section.key}>
              <h2>{section.title}</h2>
              <p>{material.content[section.key]}</p>
            </div>
          ))}
        </motion.article>

        <div className="flex flex-col sm:flex-row gap-4">
          <Link
            href={`/quiz/${material.slug}`}
            className="btn-primary flex items-center justify-center gap-2"
          >
            <HelpCircle className="w-5 h-5" />
            Kerjakan Quiz
          </Link>
          <Link
            href="/materi"
            className="btn-secondary flex items-center justify-center gap-2"
          >
            Materi Lainnya
          </Link>
        </div>
      </main>
    </div>
  );
}
