import { MetadataRoute } from 'next'
import { materials } from '@/data/materials'

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://digital-center-academy.vercel.app'
  
  const materialUrls = materials.map((m) => ({
    url: `${baseUrl}/materi/${m.slug}`,
    lastModified: new Date(),
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }))

  return [
    { url: baseUrl, lastModified: new Date(), changeFrequency: 'daily', priority: 1 },
    { url: `${baseUrl}/dashboard`, lastModified: new Date(), changeFrequency: 'daily', priority: 0.9 },
    { url: `${baseUrl}/materi`, lastModified: new Date(), changeFrequency: 'weekly', priority: 0.9 },
    ...materialUrls,
  ]
}
