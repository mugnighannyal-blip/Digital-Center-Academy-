"use client";
import Sidebar from "@/components/Sidebar";
import { motion } from "framer-motion";
import { Shield, Target, Users, BookOpen } from "lucide-react";

export default function TentangPage() {
  return (
    <div className="min-h-screen bg-gradient-radial">
      <Sidebar />
      <main className="ml-64 p-6 lg:p-8 max-w-3xl">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-3xl font-bold text-white mb-4">Tentang Digital Center Academy</h1>
          <div className="glass rounded-2xl p-6 prose-dark space-y-4">
            <p>Digital Center Academy (DCA) adalah platform pembelajaran online berbahasa Indonesia yang berfokus pada dunia digital dan keamanan siber.</p>
            <p>Kami menyediakan materi sistematis dari tingkat dasar hingga lanjutan, dilengkapi kuis interaktif, pelacakan progres, dan sertifikat untuk mendukung perjalanan belajar Anda.</p>
            <h2>Visi</h2>
            <p>Menjadi pusat pembelajaran digital terdepan di Indonesia yang mudah diakses dan berkualitas tinggi.</p>
            <h2>Misi</h2>
            <ul>
              <li>Menyediakan materi berkualitas dalam Bahasa Indonesia</li>
              <li>Meningkatkan literasi digital dan kesadaran keamanan siber</li>
              <li>Membantu generasi muda membangun keterampilan masa depan</li>
            </ul>
            <p className="text-emerald-400 font-medium">Belajar Dunia Digital, Membangun Masa Depan.</p>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
